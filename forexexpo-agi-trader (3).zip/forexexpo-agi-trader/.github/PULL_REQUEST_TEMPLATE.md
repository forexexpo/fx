## What does this PR do?

## Why

## How was this tested?
- [ ] Ran `python main.py backtest --synthetic --count 2000` and confirmed it completes without errors
- [ ] Tested against multiple instruments if the change touches `backtester.py` or `live_trader.py`

## Checklist
- [ ] No real API keys, account IDs, or `.env` file committed
- [ ] Any change to risk or position-sizing defaults (`config.py`) is called out explicitly below
- [ ] Any change to the live-trading safeguards (`OANDA_ENVIRONMENT` / `CONFIRM_LIVE_TRADING`) is called out explicitly below

## Notes on risk/safety changes (if any)
