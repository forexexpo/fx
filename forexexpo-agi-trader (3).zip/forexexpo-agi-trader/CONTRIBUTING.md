# Contributing to fx

Thanks for considering a contribution to forexexpo's trading bot. This is
a small, safety-conscious project — a few extra guardrails apply because
the code places real orders when misconfigured.

## Before you start

- Check open [issues](https://github.com/forexexpo/fx/issues) and
  [pull requests](https://github.com/forexexpo/fx/pulls) to avoid
  duplicating work.
- For anything nontrivial (a new strategy factor, a change to risk
  sizing, a new broker integration), open an issue first to discuss the
  approach before writing code.

## Development setup

```bash
git clone https://github.com/forexexpo/fx.git
cd fx
pip install -r requirements.txt
cp .env.example .env   # fill in an OANDA *practice* account key, or skip
                        # this entirely if you're only touching synthetic
                        # backtests
```

You do not need real credentials to develop or test most changes — the
synthetic data path (`--synthetic`) exercises the full pipeline offline.

## Making changes

1. Create a branch off `main`.
2. Make your change. Keep `indicators.py` free of new dependencies where
   possible — it's meant to stay auditable pandas/numpy only.
3. Run the smoke test before opening a PR:

   ```bash
   python main.py backtest --synthetic --count 2000 --instruments EUR_USD,GBP_USD,USD_JPY
   ```

4. Open a PR using the provided template. Explicitly call out any change
   to:
   - default risk parameters in `config.py` (`risk_per_trade_pct`,
     `stop_loss_atr_mult`, `take_profit_atr_mult`, `max_open_positions`)
   - the live-trading safeguards in `live_trader.py` / `config.py`
     (`OANDA_ENVIRONMENT`, `CONFIRM_LIVE_TRADING`)

Changes touching either of those get closer review, since they affect
how real money could be put at risk.

## What to avoid

- Don't commit a real `.env`, API key, or account ID — `.env` is
  gitignored; keep it that way.
- Don't make broker SDK imports (`oandapyV20`) module-level — keep them
  lazy (imported inside the function that needs them) so the rest of the
  codebase still runs without that package installed.
- Don't weaken or bypass the live-order safeguards as a side effect of
  an unrelated change.

## Reporting bugs / requesting features

Use the [issue templates](https://github.com/forexexpo/fx/issues/new/choose).
For security vulnerabilities, follow [SECURITY.md](SECURITY.md) instead of
opening a public issue.

## Code of conduct

This project follows the [Code of Conduct](CODE_OF_CONDUCT.md) — please
read it before participating.
