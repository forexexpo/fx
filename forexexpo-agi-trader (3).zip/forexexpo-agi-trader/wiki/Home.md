# forexexpo / fx — Wiki

Welcome to the wiki for **fx**, forexexpo's rules-based, multi-instrument
forex trading bot.

## Start here

- [README](https://github.com/forexexpo/fx/blob/main/README.md) — setup, usage, and honest limitations
- [LICENSE](https://github.com/forexexpo/fx/blob/main/LICENSE) — MIT, plus a trading disclaimer
- [SECURITY.md](https://github.com/forexexpo/fx/blob/main/SECURITY.md) — how to report vulnerabilities

## Pages (create these as you go)

- **Architecture** — how signal generation, risk management, backtesting,
  and live execution fit together across `strategy.py`, `risk_manager.py`,
  `backtester.py`, and `live_trader.py`
- **Strategy** — the multi-factor scoring model (trend, momentum, MACD,
  volatility) and how to tune the weights in `config.py`
- **Backtesting Guide** — synthetic vs. real OANDA backtests, multi-instrument
  portfolio runs, and how to read the report output
- **Live Trading Safety** — the two-flag safeguard before any real order is
  placed, and a recommended rollout: synthetic → OANDA practice → small live
- **Roadmap** — planned extensions (ML signal factor, alerting, equity-curve
  charting)

## Getting help

Open an [issue](https://github.com/forexexpo/fx/issues/new/choose) for bugs
or feature requests. For security concerns, use the private reporting flow
in [SECURITY.md](https://github.com/forexexpo/fx/blob/main/SECURITY.md)
instead of a public issue.

---

*Note: GitHub wikis live in their own separate git repository
(`fx.wiki.git`), so this file won't appear on the wiki automatically —
copy its contents into the wiki's "Home" page via the web editor, or
clone `git@github.com:forexexpo/fx.wiki.git` and push it there.*
