# Agent instructions for this repository

This is a forex trading bot for forexexpo. If you are an AI coding agent
(GitHub's coding agent, Copilot, or otherwise) working in this codebase,
please follow these guidelines.

## Safety-critical rules

- Never modify the live-trading safeguards in `config.py` / `live_trader.py`
  (the `OANDA_ENVIRONMENT` + `CONFIRM_LIVE_TRADING` double-check) without an
  explicit, direct instruction to do exactly that.
- Never commit real API keys, account IDs, or an actual `.env` file — it's
  gitignored; keep it that way.
- Don't silently change default risk parameters (`risk_per_trade_pct`,
  `stop_loss_atr_mult`, `take_profit_atr_mult`, `max_open_positions`) in
  `config.py`. Call out any such change explicitly in the PR description.

## Testing expectations

Before opening a PR, run:

```bash
python main.py backtest --synthetic --count 2000 --instruments EUR_USD,GBP_USD,USD_JPY
```

and confirm it completes without errors. This needs no credentials and is
also run automatically in CI (`.github/workflows/backtest.yml`).

## Style and structure

- Keep `indicators.py` dependency-light (pure pandas/numpy) — it's meant
  to be auditable without pulling in a TA library.
- Broker SDK imports (`oandapyV20`) must stay lazy (imported inside
  functions, not at module level), so the rest of the codebase keeps
  working offline without that package installed.
- `config.py` is the single source of truth for tunable parameters —
  new settings belong there, not hardcoded elsewhere.
- See the README's file table for what each module is responsible for.
