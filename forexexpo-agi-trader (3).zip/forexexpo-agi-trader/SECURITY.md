# Security Policy

## Reporting a vulnerability

If you find a security issue in this project — especially anything that
could expose API keys or account credentials, or allow unauthorized or
unintended trade execution — please report it privately rather than
opening a public issue.

Use GitHub's private vulnerability reporting:
https://github.com/forexexpo/fx/security/advisories/new

Please include:
- A description of the vulnerability and its potential impact
- Steps to reproduce
- Any relevant logs, with your API key and account ID redacted

We aim to acknowledge reports within 3 business days.

## Scope

This project reads broker credentials from a local `.env` file and calls
the OANDA v20 API. Areas of particular security interest:

- Handling, storage, and logging of API keys and account IDs (they should
  never appear in logs, error messages, or committed files)
- The two-flag safeguard that gates real order placement
  (`OANDA_ENVIRONMENT=live` **and** `CONFIRM_LIVE_TRADING=true`) — anything
  that could bypass or weaken it
- Input validation on data that feeds into order sizing or placement

## Supported versions

This is an actively developed educational project rather than a
versioned product. Security fixes are applied to `main`.
