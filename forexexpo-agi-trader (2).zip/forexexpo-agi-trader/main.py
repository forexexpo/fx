"""
main.py
-------
CLI entrypoint for the forexexpo trading system.

Examples
--------
  # Backtest instantly with synthetic data (no API keys needed):
  python main.py backtest --synthetic

  # Backtest a specific portfolio of pairs:
  python main.py backtest --synthetic --instruments EUR_USD,GBP_USD,USD_JPY

  # Backtest on real OANDA history (requires .env credentials):
  python main.py backtest --count 1000

  # Paper-trade against live prices (logs decisions, sends no orders):
  python main.py live --paper

  # Live trading (real orders) — only works if OANDA_ENVIRONMENT=live
  # AND CONFIRM_LIVE_TRADING=true are both set in .env:
  python main.py live
"""

import argparse

from backtester import run_portfolio_backtest
from config import SETTINGS
from data_feed import fetch_oanda_multi_candles, generate_synthetic_portfolio
from live_trader import LiveTrader


def cmd_backtest(args):
    instruments = (
        [i.strip() for i in args.instruments.split(",") if i.strip()]
        if args.instruments
        else SETTINGS.instruments
    )

    if args.synthetic:
        data = generate_synthetic_portfolio(instruments, n=args.count)
        print(f"Using synthetic data for: {', '.join(instruments)}")
    else:
        data = fetch_oanda_multi_candles(instruments, count=args.count)
        print(f"Fetched real OANDA candles for: {', '.join(instruments)}")

    result = run_portfolio_backtest(data, starting_balance=args.balance)
    print("\n--- Portfolio Backtest Results ---")
    print(result.summary())
    print("\nPer-instrument breakdown:")
    print(result.per_instrument_breakdown())


def cmd_live(args):
    trader = LiveTrader(paper=args.paper)
    trader.run_forever()


def main():
    parser = argparse.ArgumentParser(description="forexexpo AGI-style forex trading system")
    sub = parser.add_subparsers(dest="command", required=True)

    bt = sub.add_parser("backtest", help="Run a historical portfolio backtest")
    bt.add_argument("--synthetic", action="store_true", help="Use generated data instead of OANDA")
    bt.add_argument("--count", type=int, default=2000, help="Number of candles to use per instrument")
    bt.add_argument("--balance", type=float, default=10_000.0, help="Starting account balance")
    bt.add_argument(
        "--instruments", type=str, default=None,
        help="Comma-separated instruments, e.g. EUR_USD,GBP_USD,USD_JPY "
             "(defaults to INSTRUMENTS in .env)",
    )
    bt.set_defaults(func=cmd_backtest)

    live = sub.add_parser("live", help="Run the live/paper trading loop")
    live.add_argument("--paper", action="store_true", default=True,
                       help="Log decisions without sending real orders (default)")
    live.set_defaults(func=cmd_live)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
