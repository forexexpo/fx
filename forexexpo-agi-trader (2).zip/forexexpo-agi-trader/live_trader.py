"""
live_trader.py
---------------
Polls OANDA for the latest candles, runs the strategy, and either:

  - logs what it *would* do (paper mode — no orders sent), or
  - sends a real market order with attached stop-loss/take-profit
    (live mode — only if explicitly confirmed, see config.py).

Safety notes:
  * Defaults to paper mode. Live order placement requires both
    OANDA_ENVIRONMENT=live and CONFIRM_LIVE_TRADING=true.
  * Only ever holds at most one open position (max_open_positions=1 by
    default) to keep risk bounded and the logic easy to reason about.
  * This is not financial advice and comes with no performance
    guarantee. Test thoroughly on a practice account first.
"""

import logging
import time

from config import SETTINGS
from data_feed import fetch_oanda_candles
from risk_manager import RiskManager
from strategy import MultiFactorStrategy, Signal

# Keep the OANDA import lazy (inside methods) so this module still imports
# cleanly when oandapyV20 isn't installed, e.g. during offline backtesting.

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("logs/live_trader.log"),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger("forexexpo.live_trader")


class LiveTrader:
    def __init__(self, settings=SETTINGS, paper: bool = True):
        self.s = settings
        self.paper = paper
        self.strategy = MultiFactorStrategy(settings)
        self.risk_mgr = RiskManager(settings)
        self._client = None
        # instrument -> "BUY" / "SELL", for every currently open position
        # across the whole portfolio. In live mode this is refreshed from
        # the broker each cycle via _sync_open_positions(); in paper mode
        # it's tracked locally since there's no real broker state to read.
        self._open_positions: dict[str, str] = {}

    def _get_client(self):
        if self._client is None:
            import oandapyV20

            self._client = oandapyV20.API(
                access_token=self.s.oanda_api_key,
                environment=self.s.oanda_environment,
            )
        return self._client

    def _account_balance(self) -> float:
        import oandapyV20.endpoints.accounts as accounts

        client = self._get_client()
        req = accounts.AccountSummary(accountID=self.s.oanda_account_id)
        resp = client.request(req)
        return float(resp["account"]["balance"])

    def _place_order(self, instrument: str, direction: str, units: int, stop_loss: float, take_profit: float):
        import oandapyV20.endpoints.orders as orders

        order_data = {
            "order": {
                "type": "MARKET",
                "instrument": instrument,
                "units": str(units),
                "timeInForce": "FOK",
                "positionFill": "DEFAULT",
                "stopLossOnFill": {"price": f"{stop_loss:.5f}"},
                "takeProfitOnFill": {"price": f"{take_profit:.5f}"},
            }
        }
        client = self._get_client()
        req = orders.OrderCreate(accountID=self.s.oanda_account_id, data=order_data)
        return client.request(req)

    def _sync_open_positions(self):
        """Refreshes self._open_positions from the broker's actual open
        trades. Only meaningful in live mode — paper mode has no broker
        state to read, so it keeps relying on local tracking."""
        import oandapyV20.endpoints.trades as trades

        client = self._get_client()
        req = trades.OpenTrades(accountID=self.s.oanda_account_id)
        response = client.request(req)

        open_positions = {}
        for trade in response.get("trades", []):
            units = float(trade["currentUnits"])
            open_positions[trade["instrument"]] = "BUY" if units > 0 else "SELL"
        self._open_positions = open_positions

    def _is_live_confirmed(self) -> bool:
        return self.s.oanda_environment == "live" and self.s.confirm_live_trading

    def run_once(self):
        # In live mode, trust the broker's own record of what's open rather
        # than local memory (positions can close via SL/TP without the bot
        # doing anything). Paper mode has no broker state to sync from.
        if not self.paper and self._is_live_confirmed():
            try:
                self._sync_open_positions()
            except Exception as exc:  # noqa: BLE001
                log.error("Could not sync open positions (%s); using local state.", exc)

        try:
            balance = self._account_balance() if not self.paper else 10_000.0
        except Exception as exc:  # noqa: BLE001 - surface but don't crash the loop
            log.error("Could not fetch account balance (%s); skipping cycle.", exc)
            return

        for instrument in self.s.instruments:
            if len(self._open_positions) >= self.s.max_open_positions and instrument not in self._open_positions:
                log.info(
                    "Portfolio at max open positions (%d) — skipping %s this cycle.",
                    self.s.max_open_positions, instrument,
                )
                continue

            try:
                df = fetch_oanda_candles(instrument=instrument, count=self.s.candle_count)
            except Exception as exc:  # noqa: BLE001
                log.error("Could not fetch candles for %s (%s); skipping.", instrument, exc)
                continue

            if df.empty or len(df) < 60:
                log.warning("Not enough candle data for %s yet.", instrument)
                continue

            signaled = self.strategy.generate_signals(df)
            latest = signaled.iloc[-1]

            log.info(
                "[%s] signal=%s score=%.3f close=%.5f",
                instrument, latest["signal"], latest["score"], latest["close"],
            )

            if instrument in self._open_positions:
                log.info(
                    "[%s] Position already open (%s) — skipping new entry.",
                    instrument, self._open_positions[instrument],
                )
                continue

            if latest["signal"] not in (Signal.BUY.value, Signal.SELL.value):
                continue

            plan = self.risk_mgr.build_trade_plan(
                direction=latest["signal"],
                entry_price=latest["close"],
                atr_value=latest["atr"],
                account_balance=balance,
            )

            if self.paper or not self._is_live_confirmed():
                log.info(
                    "[PAPER][%s] Would place %s order: units=%d entry=%.5f sl=%.5f tp=%.5f",
                    instrument, plan.direction, plan.units, plan.entry_price,
                    plan.stop_loss, plan.take_profit,
                )
                self._open_positions[instrument] = plan.direction
                continue

            log.warning(
                "[LIVE][%s] Placing %s order: units=%d sl=%.5f tp=%.5f",
                instrument, plan.direction, plan.units, plan.stop_loss, plan.take_profit,
            )
            response = self._place_order(instrument, plan.direction, plan.units, plan.stop_loss, plan.take_profit)
            log.info("[%s] Broker response: %s", instrument, response)
            self._open_positions[instrument] = plan.direction

    def run_forever(self):
        mode = "PAPER" if self.paper or not self._is_live_confirmed() else "LIVE"
        log.info(
            "Starting forexexpo AGI trader | instruments=%s granularity=%s max_open=%d mode=%s",
            ", ".join(self.s.instruments), self.s.granularity, self.s.max_open_positions, mode,
        )
        while True:
            try:
                self.run_once()
            except Exception as exc:  # noqa: BLE001 - keep the loop alive, log and continue
                log.exception("Error during trading cycle: %s", exc)
            time.sleep(self.s.poll_seconds)
