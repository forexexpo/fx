"""
backtester.py
-------------
A simple, honest event-driven backtest: walks forward candle by candle,
opens/closes at most one position at a time, applies the same
RiskManager used in live trading, and checks stop-loss/take-profit against
each subsequent candle's high/low. No look-ahead: every decision at time t
only ever uses data up to and including t.
"""

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from config import SETTINGS
from risk_manager import RiskManager, TradePlan
from strategy import MultiFactorStrategy, Signal


@dataclass
class Trade:
    direction: str
    entry_time: pd.Timestamp
    entry_price: float
    exit_time: pd.Timestamp = None
    exit_price: float = None
    units: int = 0
    stop_loss: float = None
    take_profit: float = None
    pnl: float = 0.0
    exit_reason: str = None
    instrument: str = ""


@dataclass
class BacktestResult:
    trades: list = field(default_factory=list)
    equity_curve: pd.Series = None
    starting_balance: float = 0.0
    ending_balance: float = 0.0

    @property
    def total_return_pct(self) -> float:
        if self.starting_balance == 0:
            return 0.0
        return (self.ending_balance / self.starting_balance - 1) * 100

    @property
    def win_rate_pct(self) -> float:
        closed = [t for t in self.trades if t.exit_price is not None]
        if not closed:
            return 0.0
        wins = sum(1 for t in closed if t.pnl > 0)
        return wins / len(closed) * 100

    @property
    def max_drawdown_pct(self) -> float:
        if self.equity_curve is None or self.equity_curve.empty:
            return 0.0
        running_max = self.equity_curve.cummax()
        drawdown = (self.equity_curve - running_max) / running_max
        return drawdown.min() * 100

    @property
    def sharpe_ratio(self) -> float:
        if self.equity_curve is None or len(self.equity_curve) < 2:
            return 0.0
        returns = self.equity_curve.pct_change().dropna()
        if returns.std() == 0:
            return 0.0
        # Annualization factor is approximate for intraday forex candles;
        # treat as a relative comparison metric, not a precise figure.
        return float(np.sqrt(252 * 24 * 4) * returns.mean() / returns.std())

    def summary(self) -> str:
        closed = [t for t in self.trades if t.exit_price is not None]
        return (
            f"Trades: {len(closed)}\n"
            f"Win rate: {self.win_rate_pct:.1f}%\n"
            f"Total return: {self.total_return_pct:.2f}%\n"
            f"Max drawdown: {self.max_drawdown_pct:.2f}%\n"
            f"Sharpe (approx): {self.sharpe_ratio:.2f}\n"
            f"Ending balance: {self.ending_balance:,.2f} (from {self.starting_balance:,.2f})"
        )

    def per_instrument_breakdown(self) -> str:
        closed = [t for t in self.trades if t.exit_price is not None]
        if not closed:
            return "No closed trades."
        lines = []
        for instrument in sorted({t.instrument for t in closed}):
            instr_trades = [t for t in closed if t.instrument == instrument]
            wins = sum(1 for t in instr_trades if t.pnl > 0)
            pnl = sum(t.pnl for t in instr_trades)
            win_rate = wins / len(instr_trades) * 100
            label = instrument or "(unlabeled)"
            lines.append(
                f"  {label}: {len(instr_trades)} trades, "
                f"win rate {win_rate:.1f}%, pnl {pnl:+.2f}"
            )
        return "\n".join(lines)


def run_backtest(
    ohlc_df: pd.DataFrame,
    starting_balance: float = 10_000.0,
    settings=SETTINGS,
) -> BacktestResult:
    strategy = MultiFactorStrategy(settings)
    risk_mgr = RiskManager(settings)

    signaled = strategy.generate_signals(ohlc_df)

    balance = starting_balance
    open_trade: Trade | None = None
    trades: list[Trade] = []
    equity_points = []

    for timestamp, row in signaled.iterrows():
        # 1. Manage any open position first: check stop/take against this candle.
        if open_trade is not None:
            hit_stop = (
                row["low"] <= open_trade.stop_loss
                if open_trade.direction == "BUY"
                else row["high"] >= open_trade.stop_loss
            )
            hit_take = (
                row["high"] >= open_trade.take_profit
                if open_trade.direction == "BUY"
                else row["low"] <= open_trade.take_profit
            )

            if hit_stop or hit_take:
                exit_price = open_trade.stop_loss if hit_stop else open_trade.take_profit
                direction_mult = 1 if open_trade.direction == "BUY" else -1
                pnl = (exit_price - open_trade.entry_price) * direction_mult * abs(open_trade.units)

                open_trade.exit_time = timestamp
                open_trade.exit_price = exit_price
                open_trade.pnl = pnl
                open_trade.exit_reason = "stop_loss" if hit_stop else "take_profit"

                balance += pnl
                trades.append(open_trade)
                open_trade = None

        # 2. If flat, consider opening a new position on this candle's signal.
        if open_trade is None and pd.notna(row.get("atr")) and row["atr"] > 0:
            if row["signal"] in (Signal.BUY.value, Signal.SELL.value):
                plan: TradePlan = risk_mgr.build_trade_plan(
                    direction=row["signal"],
                    entry_price=row["close"],
                    atr_value=row["atr"],
                    account_balance=balance,
                )
                open_trade = Trade(
                    direction=plan.direction,
                    entry_time=timestamp,
                    entry_price=plan.entry_price,
                    units=plan.units,
                    stop_loss=plan.stop_loss,
                    take_profit=plan.take_profit,
                )

        # 3. Mark-to-market equity for this bar (unrealized P&L on open trade).
        unrealized = 0.0
        if open_trade is not None:
            direction_mult = 1 if open_trade.direction == "BUY" else -1
            unrealized = (row["close"] - open_trade.entry_price) * direction_mult * abs(open_trade.units)
        equity_points.append((timestamp, balance + unrealized))

    equity_curve = pd.Series({t: v for t, v in equity_points})

    return BacktestResult(
        trades=trades,
        equity_curve=equity_curve,
        starting_balance=starting_balance,
        ending_balance=equity_curve.iloc[-1] if not equity_curve.empty else starting_balance,
    )


def run_portfolio_backtest(
    ohlc_by_instrument: dict[str, pd.DataFrame],
    starting_balance: float = 10_000.0,
    settings=SETTINGS,
) -> BacktestResult:
    """
    Same walk-forward logic as run_backtest, generalized to several
    instruments sharing one account balance and one portfolio-wide cap on
    simultaneously open positions (settings.max_open_positions).

    Instruments are stepped through in lockstep over the union of all their
    timestamps. An instrument with no candle at a given timestamp simply
    keeps its last-known price for mark-to-market and exit checks until its
    next candle arrives.
    """
    strategy = MultiFactorStrategy(settings)
    risk_mgr = RiskManager(settings)

    signaled = {instr: strategy.generate_signals(df) for instr, df in ohlc_by_instrument.items()}
    all_timestamps = sorted(set().union(*(df.index for df in signaled.values())))

    balance = starting_balance
    open_trades: dict[str, Trade] = {}
    trades: list[Trade] = []
    equity_points = []
    last_row: dict[str, pd.Series] = {instr: None for instr in signaled}

    for ts in all_timestamps:
        for instr, df in signaled.items():
            if ts in df.index:
                last_row[instr] = df.loc[ts]

        # 1. Manage open positions: check stop/take on instruments with a
        #    fresh candle this tick.
        for instr in list(open_trades.keys()):
            df = signaled[instr]
            if ts not in df.index:
                continue
            row = df.loc[ts]
            trade = open_trades[instr]

            hit_stop = (
                row["low"] <= trade.stop_loss
                if trade.direction == "BUY"
                else row["high"] >= trade.stop_loss
            )
            hit_take = (
                row["high"] >= trade.take_profit
                if trade.direction == "BUY"
                else row["low"] <= trade.take_profit
            )

            if hit_stop or hit_take:
                exit_price = trade.stop_loss if hit_stop else trade.take_profit
                direction_mult = 1 if trade.direction == "BUY" else -1
                pnl = (exit_price - trade.entry_price) * direction_mult * abs(trade.units)

                trade.exit_time = ts
                trade.exit_price = exit_price
                trade.pnl = pnl
                trade.exit_reason = "stop_loss" if hit_stop else "take_profit"

                balance += pnl
                trades.append(trade)
                del open_trades[instr]

        # 2. Consider new entries, respecting the portfolio-wide position cap.
        for instr, df in signaled.items():
            if len(open_trades) >= settings.max_open_positions:
                break
            if instr in open_trades or ts not in df.index:
                continue

            row = df.loc[ts]
            if pd.isna(row.get("atr")) or row["atr"] <= 0:
                continue
            if row["signal"] not in (Signal.BUY.value, Signal.SELL.value):
                continue

            plan = risk_mgr.build_trade_plan(
                direction=row["signal"],
                entry_price=row["close"],
                atr_value=row["atr"],
                account_balance=balance,
            )
            open_trades[instr] = Trade(
                direction=plan.direction,
                entry_time=ts,
                entry_price=plan.entry_price,
                units=plan.units,
                stop_loss=plan.stop_loss,
                take_profit=plan.take_profit,
                instrument=instr,
            )

        # 3. Mark-to-market equity across every open position.
        unrealized = 0.0
        for instr, trade in open_trades.items():
            row = last_row[instr]
            if row is None:
                continue
            direction_mult = 1 if trade.direction == "BUY" else -1
            unrealized += (row["close"] - trade.entry_price) * direction_mult * abs(trade.units)
        equity_points.append((ts, balance + unrealized))

    equity_curve = pd.Series({t: v for t, v in equity_points})

    return BacktestResult(
        trades=trades,
        equity_curve=equity_curve,
        starting_balance=starting_balance,
        ending_balance=equity_curve.iloc[-1] if not equity_curve.empty else starting_balance,
    )
