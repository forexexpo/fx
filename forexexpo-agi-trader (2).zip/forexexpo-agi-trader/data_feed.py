"""
data_feed.py
------------
Two sources of OHLC price data:

1. `fetch_oanda_candles`  — real historical candles from the OANDA v20 API.
   Requires OANDA_API_KEY in your environment (see .env.example).

2. `generate_synthetic_candles` — a seeded random-walk price series with no
   external dependency, so you can run and inspect the backtester with zero
   setup before wiring up real credentials.
"""

import hashlib

import numpy as np
import pandas as pd

from config import SETTINGS

# Rough, illustrative starting levels so synthetic data at least looks like
# the right instrument. Not live prices — only used to seed the random walk.
DEFAULT_START_PRICES = {
    "EUR_USD": 1.1000,
    "GBP_USD": 1.2700,
    "USD_JPY": 150.00,
    "AUD_USD": 0.6600,
    "USD_CHF": 0.9000,
    "USD_CAD": 1.3600,
    "NZD_USD": 0.6100,
}


def _stable_seed(text: str) -> int:
    """Deterministic seed derived from a string (Python's hash() is
    randomized per process, so it can't be used for reproducible seeds)."""
    return int(hashlib.md5(text.encode()).hexdigest(), 16) % 10_000


def generate_synthetic_candles(
    n: int = 2000,
    start_price: float = 1.1000,
    seed: int = 7,
    freq_minutes: int = 15,
    end_time: pd.Timestamp | None = None,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    # Small random walk with mild mean-reversion and occasional trend bursts,
    # to give the indicators something realistic-ish to react to.
    returns = rng.normal(loc=0.0, scale=0.0006, size=n)
    trend_bursts = np.zeros(n)
    for start in rng.integers(0, n, size=max(n // 200, 1)):
        length = rng.integers(20, 80)
        direction = rng.choice([-1, 1])
        end = min(start + length, n)
        trend_bursts[start:end] += direction * 0.0004

    close = start_price * np.cumprod(1 + returns + trend_bursts)

    high = close * (1 + np.abs(rng.normal(0, 0.0003, size=n)))
    low = close * (1 - np.abs(rng.normal(0, 0.0003, size=n)))
    open_ = np.roll(close, 1)
    open_[0] = start_price

    end_time = end_time or pd.Timestamp.utcnow()
    timestamps = pd.date_range(end=end_time, periods=n, freq=f"{freq_minutes}min")

    df = pd.DataFrame(
        {"open": open_, "high": high, "low": low, "close": close}, index=timestamps
    )
    return df


def generate_synthetic_portfolio(
    instruments: list[str],
    n: int = 2000,
    freq_minutes: int = 15,
) -> dict[str, pd.DataFrame]:
    """
    Generates synthetic candles for several instruments at once, sharing the
    same timestamp index (same n, freq, and end time) so a portfolio
    backtest can walk them forward in lockstep. Each instrument still gets
    its own deterministic seed and a plausible starting price, so the
    series aren't identical.
    """
    shared_end_time = pd.Timestamp.utcnow()
    portfolio = {}
    for instrument in instruments:
        portfolio[instrument] = generate_synthetic_candles(
            n=n,
            start_price=DEFAULT_START_PRICES.get(instrument, 1.0000),
            seed=_stable_seed(instrument),
            freq_minutes=freq_minutes,
            end_time=shared_end_time,
        )
    return portfolio


def fetch_oanda_candles(
    instrument: str | None = None,
    granularity: str | None = None,
    count: int = 500,
) -> pd.DataFrame:
    """
    Pulls the most recent `count` candles for `instrument` from OANDA.
    Raises a clear error if credentials are missing rather than failing
    with an opaque exception deep inside the SDK.
    """
    import oandapyV20
    import oandapyV20.endpoints.instruments as instruments

    s = SETTINGS
    if not s.oanda_api_key or not s.oanda_account_id:
        raise RuntimeError(
            "OANDA_API_KEY / OANDA_ACCOUNT_ID are not set. "
            "Copy .env.example to .env and fill them in, or use "
            "generate_synthetic_candles() for offline testing."
        )

    instrument = instrument or s.instruments[0]
    granularity = granularity or s.granularity

    client = oandapyV20.API(
        access_token=s.oanda_api_key,
        environment=s.oanda_environment,
    )
    params = {"count": count, "granularity": granularity, "price": "M"}
    request = instruments.InstrumentsCandles(instrument=instrument, params=params)
    response = client.request(request)

    rows = []
    for candle in response["candles"]:
        if not candle["complete"]:
            continue
        rows.append(
            {
                "time": pd.to_datetime(candle["time"]),
                "open": float(candle["mid"]["o"]),
                "high": float(candle["mid"]["h"]),
                "low": float(candle["mid"]["l"]),
                "close": float(candle["mid"]["c"]),
                "volume": int(candle["volume"]),
            }
        )

    df = pd.DataFrame(rows).set_index("time")
    return df


def fetch_oanda_multi_candles(
    instruments: list[str],
    granularity: str | None = None,
    count: int = 500,
) -> dict[str, pd.DataFrame]:
    """Fetches real OANDA candles for several instruments in one call."""
    return {
        instrument: fetch_oanda_candles(instrument=instrument, granularity=granularity, count=count)
        for instrument in instruments
    }
