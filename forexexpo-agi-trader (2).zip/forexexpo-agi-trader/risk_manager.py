"""
risk_manager.py
----------------
Turns a signal into a concrete trade plan: position size, stop-loss and
take-profit levels. Sizing is based on a fixed fraction of account equity
risked per trade (a standard, conservative approach), not on conviction
or "confidence" — the strategy's score is used only to pick direction.
"""

from dataclasses import dataclass

from config import SETTINGS


@dataclass
class TradePlan:
    direction: str          # "BUY" or "SELL"
    entry_price: float
    stop_loss: float
    take_profit: float
    units: int              # positive = long, negative = short


class RiskManager:
    def __init__(self, settings=SETTINGS):
        self.s = settings

    def build_trade_plan(
        self,
        direction: str,
        entry_price: float,
        atr_value: float,
        account_balance: float,
        pip_value_per_unit: float = 0.0001,
    ) -> TradePlan:
        s = self.s

        stop_distance = max(atr_value * s.stop_loss_atr_mult, 1e-6)
        take_distance = atr_value * s.take_profit_atr_mult

        if direction == "BUY":
            stop_loss = entry_price - stop_distance
            take_profit = entry_price + take_distance
        else:  # SELL
            stop_loss = entry_price + stop_distance
            take_profit = entry_price - take_distance

        risk_amount = account_balance * (s.risk_per_trade_pct / 100)
        # units such that (stop_distance * pip_value_per_unit_price_move) * units == risk_amount
        units = int(risk_amount / stop_distance) if stop_distance > 0 else 0
        units = max(units, 1)

        if direction == "SELL":
            units = -units

        return TradePlan(
            direction=direction,
            entry_price=entry_price,
            stop_loss=round(stop_loss, 5),
            take_profit=round(take_profit, 5),
            units=units,
        )
