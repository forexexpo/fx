# forexexpo Trader

A full pipeline for a rules-based forex trading system: signal generation →
backtesting → paper/live execution, built for forexexpo.

**Naming note:** this is described in places as an "AGI forex trader," but
to be accurate about what the code actually does — it's a multi-factor,
rules-based decision system (moving averages, RSI, MACD, Bollinger Bands
blended into one score), not a general intelligence and not a trained
model. It's structured so any factor can later be swapped for a machine
learning model's output without changing the rest of the pipeline.

## What's in the box

| File | Purpose |
|---|---|
| `config.py` | All settings, loaded from `.env` |
| `indicators.py` | SMA, EMA, RSI, MACD, Bollinger Bands, ATR |
| `strategy.py` | Combines indicators into a BUY/SELL/HOLD signal + confidence score |
| `risk_manager.py` | Position sizing, stop-loss/take-profit from ATR |
| `data_feed.py` | Historical candles from OANDA, or synthetic data for offline testing |
| `backtester.py` | Event-driven backtest with win rate, drawdown, Sharpe |
| `live_trader.py` | Polls prices, runs the strategy, places (or logs) orders |
| `main.py` | CLI entrypoint |

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env
# edit .env with your OANDA practice-account API key and account ID
```

You can get a free OANDA practice account and API key at
https://www.oanda.com/demo-account/ — no real money is required to test
this system.

## Multi-instrument (portfolio) trading

The bot trades a **portfolio** of pairs, not just one. Set the list in
`.env`:

```
INSTRUMENTS=EUR_USD,GBP_USD,USD_JPY
```

`max_open_positions` in `config.py` (default 3) is a **portfolio-wide**
cap, not per instrument — it bounds how many positions can be open across
all pairs combined at once, which is what actually limits your total
risk exposure. Raise it if you want more pairs trading concurrently.

## Usage

Run a backtest instantly with generated data, no credentials needed:

```bash
python main.py backtest --synthetic --count 3000
```

Backtest a specific set of pairs, overriding `.env`:

```bash
python main.py backtest --synthetic --instruments EUR_USD,GBP_USD,USD_JPY,AUD_USD
```

Backtest against real historical OANDA prices for whatever's in `INSTRUMENTS`:

```bash
python main.py backtest --count 2000
```

Paper-trade against live prices (evaluates and logs decisions, sends no
real orders):

```bash
python main.py live --paper
```

Live trading is deliberately hard to turn on by accident. It only sends
real orders if **both** are true in `.env`:

```
OANDA_ENVIRONMENT=live
CONFIRM_LIVE_TRADING=true
```

## Tuning the strategy

The factor weights, thresholds, and risk settings all live in
`config.py` (`Settings` dataclass) — no code changes needed to
experiment with different weightings or risk-per-trade percentages.

## License

MIT — see [LICENSE](LICENSE). Includes a trading disclaimer: this is
educational software, not financial advice, and forex trading carries
substantial risk of loss.

## Honest limitations

- The included strategy is a straightforward technical-indicator blend.
  It has no edge guaranteed — the synthetic backtest above will often
  show a *loss*, which is expected for a random-walk price series with
  no genuine signal, and is included so you can see the pipeline behave
  honestly rather than showing a fabricated good result.
- Past backtest performance, on synthetic or real data, does not predict
  future results. Forex trading carries substantial risk of loss.
- This is not financial advice. Test extensively on a practice account
  before ever pointing it at a funded, live account, and never risk
  money you can't afford to lose.
