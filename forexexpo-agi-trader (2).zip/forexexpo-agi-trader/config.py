"""
config.py
---------
Central configuration for the forexexpo trading system.

All secrets are loaded from environment variables (via a local .env file,
never committed to source control). Copy .env.example to .env and fill
in your own OANDA credentials before running live or paper modes.
"""

import os
from dataclasses import dataclass, field
from dotenv import load_dotenv

load_dotenv()


@dataclass
class Settings:
    # --- Broker credentials (OANDA v20 API) ---
    oanda_api_key: str = os.getenv("OANDA_API_KEY", "")
    oanda_account_id: str = os.getenv("OANDA_ACCOUNT_ID", "")
    # "practice" (demo) or "live" — defaults to practice for safety.
    oanda_environment: str = os.getenv("OANDA_ENVIRONMENT", "practice")

    # --- Instruments & timeframe ---
    # Comma-separated in .env, e.g. INSTRUMENTS=EUR_USD,GBP_USD,USD_JPY
    instruments: list = field(
        default_factory=lambda: [
            s.strip() for s in os.getenv("INSTRUMENTS", "EUR_USD").split(",") if s.strip()
        ]
    )
    granularity: str = os.getenv("GRANULARITY", "M15")  # OANDA candle granularity

    # --- Strategy weights (multi-factor signal blend) ---
    weight_trend: float = 0.4      # moving-average crossover / trend following
    weight_momentum: float = 0.3   # RSI
    weight_macd: float = 0.2       # MACD histogram
    weight_volatility: float = 0.1  # Bollinger Band position

    signal_buy_threshold: float = 0.35
    signal_sell_threshold: float = -0.35

    # --- Risk management ---
    risk_per_trade_pct: float = 1.0   # % of account equity risked per trade
    stop_loss_atr_mult: float = 1.5
    take_profit_atr_mult: float = 3.0
    atr_period: int = 14
    # Portfolio-wide cap on simultaneously open positions, across ALL
    # instruments combined — not per instrument. Raise this if you want
    # several pairs open at once; keep it low to bound total exposure.
    max_open_positions: int = 3

    # --- Live loop ---
    poll_seconds: int = 60
    candle_count: int = 300  # how many historical candles to pull each cycle

    # --- Safety ---
    # Live orders are only ever sent if BOTH of these are true:
    #   1. oanda_environment == "live"
    #   2. this flag is explicitly set to True by the operator
    confirm_live_trading: bool = os.getenv("CONFIRM_LIVE_TRADING", "false").lower() == "true"


SETTINGS = Settings()
