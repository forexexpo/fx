"""
strategy.py
-----------
The "intelligence" layer. Rather than relying on a single indicator, this
blends several independent signals into one confidence score in [-1, +1]:

    +1  = maximally bullish        -1  = maximally bearish

Each factor is normalized to that same [-1, +1] range and then combined
with configurable weights, so the strategy is easy to extend — add a new
factor method, give it a weight, done. This structure also makes it a
natural place to later swap any factor for a trained ML model's output
(e.g. replace `_trend_factor` with a model.predict() call) without
touching the rest of the pipeline.

This is a rules-based decision system, not a general-purpose AI — it does
not learn on its own and has no notion of "intelligence" beyond the
weighted combination of indicators defined here. It is meant to be a
clear, auditable starting point.
"""

from dataclasses import dataclass
from enum import Enum

import numpy as np
import pandas as pd

from config import SETTINGS
from indicators import add_all_indicators


class Signal(Enum):
    BUY = "BUY"
    SELL = "SELL"
    HOLD = "HOLD"


@dataclass
class Decision:
    signal: Signal
    score: float
    factors: dict


class MultiFactorStrategy:
    def __init__(self, settings=SETTINGS):
        self.s = settings

    # ---- individual factors, each returns a value in [-1, 1] ----

    def _trend_factor(self, row: pd.Series) -> float:
        if pd.isna(row["sma_fast"]) or pd.isna(row["sma_slow"]) or row["sma_slow"] == 0:
            return 0.0
        spread = (row["sma_fast"] - row["sma_slow"]) / row["sma_slow"]
        return float(np.clip(spread * 50, -1, 1))  # scale so ~2% spread saturates

    def _momentum_factor(self, row: pd.Series) -> float:
        # RSI 50 = neutral, 70+ overbought (bearish tilt), 30- oversold (bullish tilt).
        if pd.isna(row["rsi"]):
            return 0.0
        return float(np.clip((50 - row["rsi"]) / 25, -1, 1))

    def _macd_factor(self, row: pd.Series) -> float:
        if pd.isna(row["macd_hist"]) or row["close"] == 0:
            return 0.0
        normalized = row["macd_hist"] / row["close"] * 1000
        return float(np.clip(normalized, -1, 1))

    def _volatility_factor(self, row: pd.Series) -> float:
        if pd.isna(row["bb_upper"]) or pd.isna(row["bb_lower"]) or row["bb_upper"] == row["bb_lower"]:
            return 0.0
        # Position within the bands: -1 at lower band, +1 at upper band.
        pos = (row["close"] - row["bb_mid"]) / ((row["bb_upper"] - row["bb_lower"]) / 2)
        pos = float(np.clip(pos, -1, 1))
        # Mean-reversion framing: near the upper band is a bearish tilt, near
        # the lower band is a bullish tilt, so invert.
        return -pos

    def score_row(self, row: pd.Series) -> Decision:
        s = self.s

        trend = self._trend_factor(row)
        momentum = self._momentum_factor(row)
        macd_f = self._macd_factor(row)
        vol_f = self._volatility_factor(row)

        total = (
            s.weight_trend * trend
            + s.weight_momentum * momentum
            + s.weight_macd * macd_f
            + s.weight_volatility * vol_f
        )
        total = float(np.clip(total, -1, 1))

        if total >= s.signal_buy_threshold:
            signal = Signal.BUY
        elif total <= s.signal_sell_threshold:
            signal = Signal.SELL
        else:
            signal = Signal.HOLD

        return Decision(
            signal=signal,
            score=total,
            factors={
                "trend": trend,
                "momentum": momentum,
                "macd": macd_f,
                "volatility": vol_f,
            },
        )

    def generate_signals(self, ohlc_df: pd.DataFrame) -> pd.DataFrame:
        """
        Takes a raw OHLC DataFrame (columns: open, high, low, close[, volume])
        and returns it enriched with indicators, score, and signal columns.
        """
        df = add_all_indicators(ohlc_df)
        scores, signals = [], []
        for _, row in df.iterrows():
            decision = self.score_row(row)
            scores.append(decision.score)
            signals.append(decision.signal.value)
        df["score"] = scores
        df["signal"] = signals
        return df
